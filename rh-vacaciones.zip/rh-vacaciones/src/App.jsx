import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import InicioSolicitud from './pantallas/InicioSolicitud';
import SubirDocumentos from './pantallas/SubirDocumentos';
import DatosIncorrectos from './pantallas/DatosIncorrectos';
import MostrarEstatus from './pantallas/MostrarEstatus';

function WebSocketManager() {
  const navigate = useNavigate();
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
    // Ajusta el puerto si tu webMethods Integration Server usa uno específico (ej. :5555)
    const ws = new WebSocket('ws://13.220.232.174:8080');

    ws.onopen = () => {
      console.log('Conectado al servidor BPM');
    };

    ws.onmessage = (event) => {
  // 1. Mostrar el mensaje crudo que llega del servidor
  console.log('Mensaje recibido por WebSocket (crudo):', event.data);

  const data = JSON.parse(event.data);
  
  // 2. Mostrar el objeto ya parseado
  console.log('Mensaje parseado a JSON:', data);
  console.log('UUID actual esperado:', sessionId);

  // Validar que el mensaje corresponde a nuestra sesión actual
  if (sessionId && data.uuid !== sessionId) {
    console.log('El mensaje fue ignorado porque el UUID no coincide.');
    return;
  }

  // Enrutamiento basado en el evento entrante desde el BPM
  switch (data.evento) {
    case 'pntSubirDocumetos':
      navigate('/subir-documentos');
      break;
    case 'pntDatosIncorrectos':
      navigate('/datos-incorrectos');
      break;
    case 'tuMostrarEstatus':
      navigate('/mostrar-estatus', { state: { estatus: data.estatus } });
      break;
    default:
      console.warn('Evento no reconocido:', data.evento);
  }
};

    ws.onerror = (error) => {
      console.error('Error en WebSocket:', error);
    };

    return () => {
      ws.close();
    };
  }, [navigate, sessionId]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Routes>
        <Route path="/" element={<InicioSolicitud setSessionId={setSessionId} />} />
        <Route path="/subir-documentos" element={<SubirDocumentos sessionId={sessionId} />} />
        <Route path="/datos-incorrectos" element={<DatosIncorrectos />} />
        <Route path="/mostrar-estatus" element={<MostrarEstatus />} />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <WebSocketManager />
    </Router>
  );
}