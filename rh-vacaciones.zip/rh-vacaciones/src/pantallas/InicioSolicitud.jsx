import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

export default function InicioSolicitud({ setSessionId }) {
  const [formData, setFormData] = useState({
    numeroEmpleado: '',
    tiempoVacaciones: '',
    anosTrabajados: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // 1. Generar UUID sin guiones (para coincidir con tu formato de ejemplo 6af351494e632eeb02d092a2)
    const newUuid = uuidv4().replace(/-/g, ''); 
    setSessionId(newUuid);

    // 2. Aquí debes enviar formData + newUuid a tu webMethods IS (mediante HTTP POST o el mismo WebSocket)
    // para disparar el evento "Start Process".
    console.log("Iniciando proceso con UUID:", newUuid, formData);
    
    // Simulación de envío exitoso:
    alert('Solicitud enviada al BPM. Esperando validación de datos...');
  };

  return (
    <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md border-t-4 border-hrBlue">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">Portal RH: Solicitar Vacaciones</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Número de Empleado</label>
          <input type="text" name="numeroEmpleado" required onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hrBlue focus:border-hrBlue" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Días de Vacaciones Solicitados</label>
          <input type="number" name="tiempoVacaciones" required onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hrBlue focus:border-hrBlue" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Años Trabajados</label>
          <input type="number" name="anosTrabajados" required onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hrBlue focus:border-hrBlue" />
        </div>
        <button type="submit" 
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-hrBlue hover:bg-blue-700 focus:outline-none">
          Solicitar Vacaciones
        </button>
      </form>
    </div>
  );
}