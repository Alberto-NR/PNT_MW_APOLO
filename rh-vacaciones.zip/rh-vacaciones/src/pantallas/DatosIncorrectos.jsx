import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function DatosIncorrectos() {
  const navigate = useNavigate();

  return (
    <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md border-t-4 border-red-500 text-center">
      <div className="text-red-500 text-5xl mb-4">⚠️</div>
      <h2 className="text-2xl font-bold mb-2 text-gray-800">Datos Incorrectos</h2>
      <p className="text-gray-600 mb-6">La información proporcionada no coincide con nuestros registros de Recursos Humanos. Por favor, verifica tu número de empleado o años trabajados.</p>
      <button onClick={() => navigate('/')} 
        className="w-full py-2 px-4 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium">
        Volver al Inicio
      </button>
    </div>
  );
}