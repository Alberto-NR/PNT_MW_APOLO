import React, { useState } from 'react';

export default function SubirDocumentos({ sessionId }) {
  const [fileBase64, setFileBase64] = useState('');
  const [fileName, setFileName] = useState('');

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.name.endsWith('.txt')) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        // Extrae solo la cadena base64 del data URL
        const base64String = reader.result.replace('data:', '').replace(/^.+,/, '');
        setFileBase64(base64String);
      };
      reader.readAsDataURL(file);
    } else {
      alert("Por favor sube solo archivos .txt");
    }
  };

  const enviarDocumentoAlServidor = async () => {
    if (!fileBase64) return alert("Selecciona un documento primero");

    // PLANTILLA HTTP REQUEST AL INTEGRATION SERVER
    const urlIntegrationServer = "http://172.31.42.186:5555/invoke/TuCarpeta.Servicios/procesarDocumento"; 
    
    const bodyPayload = {
      uuid: sessionId,
      nombreArchivo: fileName,
      documentoBase64: fileBase64
    };

    try {
      /*
      // Descomentar para implementar la llamada real
      const response = await fetch(urlIntegrationServer, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          // 'Authorization': 'Basic ' + btoa('usuario:password') // Si tu IS requiere auth
        },
        body: JSON.stringify(bodyPayload)
      });
      const result = await response.json();
      */
      console.log("Enviado (Simulación):", bodyPayload);
      alert("Documento enviado al servidor para su evaluación.");
    } catch (error) {
      console.error("Error al enviar documento al IS:", error);
    }
  };

  return (
    <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md border-t-4 border-hrBlue">
      <h2 className="text-xl font-bold mb-4 text-center">Subir Comprobante / Documento (.txt)</h2>
      <p className="text-sm text-gray-500 mb-6 text-center">ID de Proceso: {sessionId}</p>
      
      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md mb-4">
        <div className="space-y-1 text-center">
          <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="flex text-sm text-gray-600 justify-center">
            <label className="relative cursor-pointer bg-white rounded-md font-medium text-hrBlue hover:text-blue-500">
              <span>Subir un archivo .txt</span>
              <input type="file" accept=".txt" className="sr-only" onChange={handleFileChange} />
            </label>
          </div>
          <p className="text-xs text-gray-500">{fileName || "Ningún archivo seleccionado"}</p>
        </div>
      </div>

      <button onClick={enviarDocumentoAlServidor}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700">
        Enviar Documento
      </button>
    </div>
  );
}