import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function MostrarEstatus() {
  const location = useLocation();
  const navigate = useNavigate();
  // 'aprobado' o 'rechazado' enviado por el WebSocket
  const estatus = location.state?.estatus || 'desconocido'; 

  const esAprobado = estatus.toLowerCase() === 'aprobado';

  return (
    <div className={`bg-white p-8 rounded-xl shadow-lg w-full max-w-md border-t-4 ${esAprobado ? 'border-green-500' : 'border-red-500'} text-center`}>
      <div className="text-5xl mb-4">
        {esAprobado ? '🎉' : '❌'}
      </div>
      <h2 className="text-2xl font-bold mb-2 text-gray-800">
        Resolución de Solicitud
      </h2>
      <p className="text-gray-600 mb-6 text-lg">
        Tus vacaciones han sido <strong className={esAprobado ? 'text-green-600' : 'text-red-600'}>{estatus}</strong>.
      </p>
      <button onClick={() => navigate('/')} 
        className="w-full py-2 px-4 bg-hrBlue text-white rounded-md hover:bg-blue-700 font-medium">
        Finalizar
      </button>
    </div>
  );
}