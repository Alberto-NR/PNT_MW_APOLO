/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        hrBlue: '#0052cc',
        hrLight: '#f4f5f7'
      }
    },
  },
  plugins: [],
}